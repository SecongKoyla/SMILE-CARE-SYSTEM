package com.smilecare.smilecare_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmilecareBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmilecareBackendApplication.class, args);
	}

}
